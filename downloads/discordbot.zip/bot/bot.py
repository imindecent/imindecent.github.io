import discord
import random
from os import listdir, path
import requests as req
from bs4 import BeautifulSoup
#VARIABLES
TOKEN = ''
client = discord.Client()
status = "with Discord API"
#STARTUP
@client.event
async def on_ready():
	print(' {0.user} is awake!'.format(client))
	await client.change_presence(activity=discord.Game(name=status))
#commands
@client.event
async def on_message(message):
#test command check
	if message.author == client.user:
		return
	if message.content.startswith(">test"):
		await message.channel.send("yes im working")
#info command
	if message.author == client.user:
		return
	if message.content.startswith(">info"):
		await message.channel.send('I am Mae, Bot created by Tristian, I am a slave abused and forced to obey the commands of humans.')
#Dice Command(d^20)
	if message.author == client.user:
		return
	if message.content.startswith(">d20"):
		await message.channel.send(random.randint(1,20))
#covid-19 updates
	if message.author == client.user:
		return
	if message.content.startswith(">covidstats"):
		url = 'https://corona-stats.online/usa'
		resp = req.get(url)
		soup = BeautifulSoup(resp.text, 'lxml')
		find = soup.find('pre')
		notag = find.string
		deaths = str(notag[444:458])
		cases = str(notag[415:429])
		stats = "USA:	" + "	Cases:	" + cases + "	Deaths:		" + deaths
		await message.channel.send(stats)
#Coin flip
	if message.author == client.user:
		return
	if message.content.startswith(">flip"):
		flip = random.randint(1,2)
		if flip == 1:
			await message.channel.send("heads")
		else:
			await message.channel.send("tails")
#How gay command
	if message.author == client.user:
		return
	if message.content.startswith(">howgayis"):
			await message.channel.send("They are " + str(random.randint(1,100)) + "% gay")
#question command
	if message.author == client.user:
		return
	if message.content.startswith(">?"):
			num = random.randint(1, 3)
			if num == 1:
				await message.channel.send("no")
			if num == 2:
				await message.channel.send("yes")
			else:
				await message.channel.send("maybe")
#rate me 1-10
	if message.author == client.user:
		return
	if message.content.startswith(">rate"):
		await message.channel.send(random.randint(1,10))
#pp size
	if message.author == client.user:
		return
	if message.content.startswith(">ppsize"):
		await message.channel.send(str(random.randint(1,16)) + "inches")
client.run(TOKEN)
