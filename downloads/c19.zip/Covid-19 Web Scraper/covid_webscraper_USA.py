import requests as req
from bs4 import BeautifulSoup

print("Covid-19-Tracking-Web-Scraping-Script Created by Skr@ckTer0")

def track():
	url = 'https://corona-stats.online/'
	resp = req.get(url) 
	soup = BeautifulSoup(resp.text, 'lxml')
	find = soup.find('pre')
	notag = find.string
	deaths = str(notag[549:563])
	cases = str(notag[520:534])
	print("\n Covid-19 in USA:" + "\n	Cases: " + cases + "\n	Deaths: " + deaths)

while True:
	track()
